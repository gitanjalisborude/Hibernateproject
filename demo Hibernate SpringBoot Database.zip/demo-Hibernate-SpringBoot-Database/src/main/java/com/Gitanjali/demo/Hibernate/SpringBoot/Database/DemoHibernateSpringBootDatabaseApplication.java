package com.Gitanjali.demo.Hibernate.SpringBoot.Database;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoHibernateSpringBootDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoHibernateSpringBootDatabaseApplication.class, args);
	}

}
