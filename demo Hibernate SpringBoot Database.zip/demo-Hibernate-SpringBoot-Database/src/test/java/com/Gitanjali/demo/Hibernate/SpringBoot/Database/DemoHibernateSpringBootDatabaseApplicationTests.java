package com.Gitanjali.demo.Hibernate.SpringBoot.Database;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoHibernateSpringBootDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
